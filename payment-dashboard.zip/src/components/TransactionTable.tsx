import { useEffect } from "react";
import { useAppDispatch, useAppSelector } from "../store/hooks";
import "./TransactionTable.css";
import { fetchTransactionData } from "../store/transactionAction";

export default function TransactionTable() {
  const dispatch = useAppDispatch();
  const allTransactions = useAppSelector((state) => state.transaction.items);

  useEffect(() => {
    dispatch(fetchTransactionData());
  }, [dispatch]);
  
  return (
    <div className="container">
      <table>
        <thead>
          <tr id="attributes">
            <th>Date</th>
            <th>Name</th>
            <th>Mail</th>
            <th>Status</th>
            <th>Value</th>
          </tr>
        </thead>
        <tbody>
          {allTransactions.map((t) => (
            <tr className="tuples" key={t.id}>
              <td>{t.date}</td>
              <td>{t.user}</td>
              <td>{t.email}</td>
              <td className={`status ${t.status}`}>{t.status}</td>
              <td>${t.currentAmount}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
