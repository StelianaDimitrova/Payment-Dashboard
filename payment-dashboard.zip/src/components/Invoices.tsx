import TransactionTable from "./TransactionTable";

import "./Invoices.css";

export default function Invoices() {
  return (
    <section id="invoices">
      <div className="table-header">
        <h2>All invoices</h2>
        <div className="table-buttons">
          <input className="search-bar" placeholder="Search" />
          <button className="btn-filter">Filter</button>
          <button className="btn-payment">+ Request Payment</button>
        </div>
      </div>
      <TransactionTable />
    </section>
  );
}
