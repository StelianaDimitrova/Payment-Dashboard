import "./TotalCard.css";

type TotalCardProps = {
  title: string;
  sum: number;
};

export default function TotalCard({ title, sum }: TotalCardProps) {
  return (
    <div className="card-container">
      <h1 className="card-title">{title}</h1>
      <p className="card-price">${sum}</p>
      <p className="card-percentage up">
        3.9% <span className="card-span">Last month</span>
      </p>
    </div>
  );
}
